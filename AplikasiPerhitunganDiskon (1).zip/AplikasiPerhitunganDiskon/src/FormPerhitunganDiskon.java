/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 * @author lenovo
 */

 import javax.swing.*;
 import java.awt.*;
 import java.awt.event.*;
 
 public class FormPerhitunganDiskon extends javax.swing.JFrame {
 
     public FormPerhitunganDiskon() {
         initComponents();
         setTitle("Aplikasi Perhitungan Diskon");
         setLocationRelativeTo(null); // agar muncul di tengah layar
 
         // 🔹 Tampilan
         jPanel1.setBackground(new Color(240, 245, 255));
         lblJudul.setFont(new Font("Segoe UI", Font.BOLD, 18));
         lblJudul.setAlignment(Label.CENTER);
 
         // 🔹 Atur label
         lblJudul.setText("Aplikasi Perhitungan Diskon");
         lblHargaAsli.setText("Harga Asli:");
         lblDiskon.setText("Diskon (%):");
         lblKupon.setText("Kode Kupon:");
         lblHargaAkhir.setText("Harga Akhir:");
         lblPenghematan.setText("Penghematan:");
 
         // 🔹 Atur ComboBox Diskon
         cmbDiskon.removeAllItems();
         cmbDiskon.addItem("5");
         cmbDiskon.addItem("10");
         cmbDiskon.addItem("20");
         cmbDiskon.addItem("30");
         cmbDiskon.addItem("50");
 
         // 🔹 Atur Slider
         sliderDiskon.setMinimum(0);
         sliderDiskon.setMaximum(100);
         sliderDiskon.setMajorTickSpacing(20);
         sliderDiskon.setPaintTicks(true);
         sliderDiskon.setPaintLabels(true);
 
         // 🔹 Hubungkan ComboBox dan Slider
         cmbDiskon.addItemListener(e -> {
             if (e.getStateChange() == ItemEvent.SELECTED) {
                 int persen = Integer.parseInt((String) cmbDiskon.getSelectedItem());
                 sliderDiskon.setValue(persen);
             }
         });
 
         sliderDiskon.addChangeListener(e -> {
             cmbDiskon.setSelectedItem(String.valueOf(sliderDiskon.getValue()));
         });
 
         // 🔹 Tombol Hitung
         btnHitung.addActionListener(e -> hitungDiskon());
 
         // 🔹 Tombol Reset
         btnReset.addActionListener(e -> resetForm());
     }
 
     private void hitungDiskon() {
         try {
             double hargaAsli = Double.parseDouble(txtHargaAsli.getText());
             double diskonPersen = sliderDiskon.getValue();
             double diskonKupon = 0;
 
             String kupon = txtKupon.getText().trim().toUpperCase();
             if (kupon.equals("HEMAT10")) {
                 diskonKupon = 10;
             } else if (kupon.equals("SUPER20")) {
                 diskonKupon = 20;
             }
 
             double totalDiskon = diskonPersen + diskonKupon;
             if (totalDiskon > 100) totalDiskon = 100;
 
             double penghematan = hargaAsli * (totalDiskon / 100);
             double hargaAkhir = hargaAsli - penghematan;
 
             txtHargaAkhir.setText(String.format("Rp %.2f", hargaAkhir));
             txtPenghematan.setText(String.format("Rp %.2f", penghematan));
 
             txtRiwayat.append("Harga: Rp " + hargaAsli +
                     " | Diskon: " + totalDiskon + "%" +
                     " | Harga Akhir: Rp " + hargaAkhir + "\n");
 
         } catch (NumberFormatException ex) {
             JOptionPane.showMessageDialog(this,
                     "Masukkan harga asli yang valid!",
                     "Error",
                     JOptionPane.ERROR_MESSAGE);
         }
     }
 
     private void resetForm() {
         txtHargaAsli.setText("");
         txtKupon.setText("");
         txtHargaAkhir.setText("");
         txtPenghematan.setText("");
         sliderDiskon.setValue(0);
         cmbDiskon.setSelectedIndex(0);
         txtRiwayat.setText("");
     }
 
     @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        lblJudul = new java.awt.Label();
        lblHargaAsli = new java.awt.Label();
        lblDiskon = new java.awt.Label();
        txtHargaAsli = new java.awt.TextField();
        cmbDiskon = new javax.swing.JComboBox<>();
        sliderDiskon = new javax.swing.JSlider();
        lblKupon = new java.awt.Label();
        txtKupon = new java.awt.TextField();
        btnHitung = new java.awt.Button();
        btnReset = new java.awt.Button();
        lblHargaAkhir = new java.awt.Label();
        txtHargaAkhir = new java.awt.TextField();
        lblPenghematan = new java.awt.Label();
        txtPenghematan = new java.awt.TextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtRiwayat = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lblJudul.setText("label1");

        lblHargaAsli.setText("label2");

        lblDiskon.setText("label3");

        txtHargaAsli.setText("textField1");

        cmbDiskon.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        lblKupon.setText("label1");

        txtKupon.setText("textField1");

        btnHitung.setLabel("button1");

        btnReset.setLabel("button2");

        lblHargaAkhir.setText("label1");

        txtHargaAkhir.setText("textField1");

        lblPenghematan.setText("label1");

        txtPenghematan.setText("textField1");

        txtRiwayat.setColumns(20);
        txtRiwayat.setRows(5);
        jScrollPane1.setViewportView(txtRiwayat);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblPenghematan, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblDiskon, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblHargaAsli, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblHargaAkhir, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblKupon, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnHitung, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 118, Short.MAX_VALUE))
                        .addGap(66, 66, 66)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtHargaAsli, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(cmbDiskon, 0, 92, Short.MAX_VALUE)
                            .addComponent(txtKupon, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnReset, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtHargaAkhir, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtPenghematan, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(sliderDiskon, javax.swing.GroupLayout.PREFERRED_SIZE, 234, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGap(34, 34, 34))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1)
                .addContainerGap())
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblJudul, javax.swing.GroupLayout.PREFERRED_SIZE, 290, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblJudul, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lblHargaAsli, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtHargaAsli, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblDiskon, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbDiskon, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(sliderDiskon, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lblKupon, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtKupon, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnHitung, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnReset, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblHargaAkhir, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtHargaAkhir, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblPenghematan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtPenghematan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(70, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(26, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
 
 
     public static void main(String args[]) {
         java.awt.EventQueue.invokeLater(() -> new FormPerhitunganDiskon().setVisible(true));
     }
 
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private java.awt.Button btnHitung;
    private java.awt.Button btnReset;
    private javax.swing.JComboBox<String> cmbDiskon;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private java.awt.Label lblDiskon;
    private java.awt.Label lblHargaAkhir;
    private java.awt.Label lblHargaAsli;
    private java.awt.Label lblJudul;
    private java.awt.Label lblKupon;
    private java.awt.Label lblPenghematan;
    private javax.swing.JSlider sliderDiskon;
    private java.awt.TextField txtHargaAkhir;
    private java.awt.TextField txtHargaAsli;
    private java.awt.TextField txtKupon;
    private java.awt.TextField txtPenghematan;
    private javax.swing.JTextArea txtRiwayat;
    // End of variables declaration//GEN-END:variables
 }
